package practica;

import java.util.Scanner;

public class practicawhile {

	public static void main(String[] args) {
		
		
		Scanner tc = new Scanner(System.in);
		
		String pass,password="Hola";
		String usuario,usuarioname="Fran";
		int intentos=0;
		
		System.out.println("Hola querido usuario, ingrese su nombre");
		usuario=tc.nextLine();
		
		if (usuarioname.equals(usuario)) {
			System.out.println("Hola bienvenido, ingrese su contraseña");
			pass=tc.nextLine();
			
			if (password.equals(pass)) {
				
				System.out.println("Hola bienvenido de nuevo querido usuario");
			  }else {
				
				while (!password.equals(pass) && intentos<3) {
					System.out.println("Contraseña incorrecta, ingresela de nuevo");
					pass=tc.nextLine();
					intentos++;
				} 
				if (password.equals(pass)) {
					System.out.println("Bienvenido");
				}
				if (intentos==3) {
					System.out.println("Intentos agotados");
				}
				 
			     }
	 }  else {
			while (!usuarioname.equals(usuario) && intentos<3) {
				
				System.out.println("Nombre incorrecto ingreselo de nuevo");
				usuario=tc.nextLine();
				intentos++;
				if (usuarioname.equals(usuario)) {
					System.out.println("Ingrese la contraseña");
					pass=tc.nextLine();
				if (password.equals(pass)) {
					System.out.println("Hola bienvenido de nuevo");
				} else {
					
					while (!password.equals(pass)&& intentos<3) {
						System.out.println("Contraseña incorrecta, ingresela de nuevo");
						pass=tc.nextLine();
						intentos++;
					} 
					if (password.equals(pass)) {
					System.out.println("Bienvenido1");
					}
				}		
				}
			}      if(intentos==3) {
			     System.out.println("Intentos agotados");
			}
		}
		
		
		
		
		
		
		
		
		

	}

}
